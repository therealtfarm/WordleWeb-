// WordleWeb — shared theme + tweaks controller
(function () {
  const STORE_KEY = 'wordleweb.prefs.v1';
  const defaults = { theme: 'light', palette: 'forest' };
  let prefs = { ...defaults };
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) prefs = { ...defaults, ...JSON.parse(raw) };
  } catch {}

  const apply = () => {
    document.documentElement.setAttribute('data-theme', prefs.theme);
    document.documentElement.setAttribute('data-palette', prefs.palette);
  };
  apply();

  const save = () => { try { localStorage.setItem(STORE_KEY, JSON.stringify(prefs)); } catch {} };

  window.WW = {
    prefs,
    setTheme(t) { prefs.theme = t; apply(); save(); notify(); },
    setPalette(p) { prefs.palette = p; apply(); save(); notify(); },
    toggleTheme() { this.setTheme(prefs.theme === 'dark' ? 'light' : 'dark'); },
    subscribe(fn) { subs.push(fn); return () => { subs = subs.filter(s => s !== fn); }; },
  };

  let subs = [];
  function notify() { subs.forEach(fn => { try { fn(prefs); } catch {} }); }

  // ── Topbar renderer (to be called once per page) ──
  window.WW.renderTopbar = function ({ tool = '', back = null } = {}) {
    const host = document.getElementById('ww-topbar');
    if (!host) return;
    host.className = 'ww-topbar';
    host.innerHTML = `
      <div class="ww-brand">
        ${back ? `<a href="${back}" class="ww-icon-btn" aria-label="Back" style="margin-right:4px;">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3l-5 5 5 5"/></svg>
        </a>` : ''}
        <a href="index.html" class="ww-brand-mark">WordleWeb</a>
        ${tool ? `<span class="ww-brand-slash">/</span><span class="ww-brand-tool">${tool}</span>` : ''}
      </div>
      <div class="ww-toolbar">
        <button class="ww-icon-btn" id="ww-palette-btn" aria-label="Palette" title="Palette">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4"><circle cx="8" cy="8" r="6"/><circle cx="8" cy="4.5" r="1" fill="currentColor" stroke="none"/><circle cx="5" cy="7" r="1" fill="currentColor" stroke="none"/><circle cx="5.5" cy="10.5" r="1" fill="currentColor" stroke="none"/><circle cx="10.5" cy="10" r="1" fill="currentColor" stroke="none"/></svg>
        </button>
        <button class="ww-icon-btn" id="ww-theme-btn" aria-label="Toggle theme">
          <svg class="ww-sun" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><circle cx="8" cy="8" r="3"/><path d="M8 1v2M8 13v2M1 8h2M13 8h2M3 3l1.5 1.5M11.5 11.5L13 13M3 13l1.5-1.5M11.5 4.5L13 3"/></svg>
          <svg class="ww-moon" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:none"><path d="M13 9.5A5.5 5.5 0 1 1 6.5 3 4.5 4.5 0 0 0 13 9.5z"/></svg>
        </button>
      </div>`;

    const themeBtn = document.getElementById('ww-theme-btn');
    const updateThemeIcon = () => {
      const sun = themeBtn.querySelector('.ww-sun');
      const moon = themeBtn.querySelector('.ww-moon');
      if (prefs.theme === 'dark') { sun.style.display = 'none'; moon.style.display = ''; }
      else { sun.style.display = ''; moon.style.display = 'none'; }
    };
    updateThemeIcon();
    themeBtn.addEventListener('click', () => { window.WW.toggleTheme(); updateThemeIcon(); });

    document.getElementById('ww-palette-btn').addEventListener('click', openPaletteSheet);
  };

  function openPaletteSheet() {
    const existing = document.getElementById('ww-palette-sheet');
    if (existing) { existing.remove(); return; }
    const sheet = document.createElement('div');
    sheet.id = 'ww-palette-sheet';
    sheet.innerHTML = `
      <style>
        #ww-palette-sheet { position: fixed; inset: 0; z-index: 200; background: rgba(0,0,0,0.35); backdrop-filter: blur(4px); display:flex; align-items:center; justify-content:center; padding: 18px; animation: wwFade 0.15s ease; }
        @keyframes wwFade { from { opacity:0; } to { opacity:1; } }
        .ww-ps-card { background: var(--paper); border: 1px solid var(--rule); border-radius: 14px; width: 100%; max-width: 320px; padding: 18px; box-shadow: var(--shadow-2); }
        .ww-ps-title { font-family: var(--font-mono); font-size: 10px; letter-spacing: 0.14em; text-transform: uppercase; color: var(--ink-mute); margin-bottom: 12px; }
        .ww-ps-row { display: flex; gap: 8px; margin-bottom: 14px; }
        .ww-ps-chip { flex: 1; border: 1px solid var(--rule); background: var(--paper-2); border-radius: 10px; padding: 10px 8px; text-align: center; font-family: var(--font-mono); font-size: 11px; color: var(--ink-mute); transition: border-color 0.15s, color 0.15s; display:flex; flex-direction:column; gap:6px; align-items:center; }
        .ww-ps-chip[aria-pressed="true"] { border-color: var(--ink); color: var(--ink); }
        .ww-ps-dot { width: 18px; height: 18px; border-radius: 50%; }
      </style>
      <div class="ww-ps-card">
        <div class="ww-ps-title">Theme</div>
        <div class="ww-ps-row">
          <button class="ww-ps-chip" data-theme="light">☀︎ Paper</button>
          <button class="ww-ps-chip" data-theme="dark">☾ Ink</button>
        </div>
        <div class="ww-ps-title">Accent</div>
        <div class="ww-ps-row">
          <button class="ww-ps-chip" data-palette="forest"><span class="ww-ps-dot" style="background:#3e7a4e"></span>Forest</button>
          <button class="ww-ps-chip" data-palette="graphite"><span class="ww-ps-dot" style="background:#4a4a4a"></span>Graphite</button>
          <button class="ww-ps-chip" data-palette="oxblood"><span class="ww-ps-dot" style="background:#8a3545"></span>Oxblood</button>
        </div>
      </div>`;
    document.body.appendChild(sheet);
    const refresh = () => {
      sheet.querySelectorAll('[data-theme]').forEach(b => b.setAttribute('aria-pressed', b.dataset.theme === prefs.theme));
      sheet.querySelectorAll('[data-palette]').forEach(b => b.setAttribute('aria-pressed', b.dataset.palette === prefs.palette));
    };
    refresh();
    sheet.addEventListener('click', (e) => {
      if (e.target === sheet) sheet.remove();
      const t = e.target.closest('[data-theme]');
      const p = e.target.closest('[data-palette]');
      if (t) { window.WW.setTheme(t.dataset.theme); refresh(); }
      if (p) { window.WW.setPalette(p.dataset.palette); refresh(); }
    });
  }
})();
