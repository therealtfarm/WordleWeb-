// WordleWeb — WhatsApp Wordle parser + stats engine

function parseChat(text) {
  const results = [];
  const lines = text.split('\n');
  const msgRe = /^[\["]?(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4}),?\s+(\d{1,2}[:\.]?\d{2}(?:[:\.]?\d{2})?(?:\s*[AaPp][Mm])?)\]?\s*[-–—]?\s*([^:]+?):\s*(.*)/;
  const wordleRe = /Wordle\s+([\d,\.]+)\s+([1-6X])\/6/i;

  for (const line of lines) {
    const mm = line.match(msgRe);
    if (!mm) continue;
    const dateStr = mm[1];
    const sender = mm[3].trim();
    const body = mm[4];
    const wm = body.match(wordleRe);
    if (!wm) continue;

    const puzzleNum = parseInt(wm[1].replace(/[,\.]/g, ''));
    const scoreRaw = wm[2].toUpperCase();
    const score = scoreRaw === 'X' ? 7 : parseInt(scoreRaw);
    const dp = dateStr.split(/[\/\-\.]/);
    let day, month, year;
    if (parseInt(dp[0]) > 12) { day = +dp[0]; month = +dp[1]; year = +dp[2]; }
    else if (parseInt(dp[1]) > 12) { month = +dp[0]; day = +dp[1]; year = +dp[2]; }
    else { day = +dp[0]; month = +dp[1]; year = +dp[2]; }
    if (year < 100) year += 2000;

    results.push({
      date: new Date(year, month - 1, day),
      dateStr: `${day}/${month}/${year}`,
      sender: cleanName(sender),
      puzzleNum, score, scoreStr: scoreRaw,
    });
  }
  return results;
}

function cleanName(name) {
  name = name.replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g, '').trim();
  if (/^\+?\d[\d\s\-]{6,}$/.test(name)) return name;
  const parts = name.split(/\s+/);
  if (parts.length > 1 && parts[0].length >= 2) return parts[0];
  return name;
}

function computeStats(results, windowFilter) {
  // windowFilter: 'all' | '7' | '30' | '90'
  if (windowFilter && windowFilter !== 'all') {
    const days = parseInt(windowFilter);
    const cutoff = new Date(Math.max(...results.map(r => r.date.getTime())) - days * 86400000);
    results = results.filter(r => r.date >= cutoff);
  }

  const players = {};
  const puzzles = {};
  for (const r of results) {
    if (!players[r.sender]) players[r.sender] = { name: r.sender, scores: [], puzzleScores: {}, dates: [] };
    if (!players[r.sender].puzzleScores[r.puzzleNum]) {
      players[r.sender].puzzleScores[r.puzzleNum] = r;
      players[r.sender].scores.push(r.score);
      players[r.sender].dates.push(r.date);
    }
    if (!puzzles[r.puzzleNum]) puzzles[r.puzzleNum] = { num: r.puzzleNum, results: [] };
    if (!puzzles[r.puzzleNum].results.find(x => x.sender === r.sender)) {
      puzzles[r.puzzleNum].results.push(r);
    }
  }

  const playerList = Object.values(players)
    .filter(p => p.scores.length >= 1)
    .sort((a, b) => avgOf(a) - avgOf(b));

  const puzzleNums = Object.keys(puzzles).map(Number).sort((a, b) => a - b);
  const allDates = results.map(r => r.date).sort((a, b) => a - b);
  const dateRange = allDates.length ? { from: allDates[0], to: allDates[allDates.length - 1] } : null;

  return { players: playerList, puzzles, puzzleNums, dateRange, totalResults: results.length };
}

function avgOf(p) { return p.scores.reduce((s, v) => s + v, 0) / Math.max(1, p.scores.length); }
function getAvg(p) { return avgOf(p).toFixed(2); }
function getDistribution(p) {
  const d = { 1:0,2:0,3:0,4:0,5:0,6:0,X:0 };
  for (const s of p.scores) { if (s === 7) d.X++; else d[s]++; }
  return d;
}

function getStreaks(p, puzzleNums) {
  let current = 0, best = 0, currentSub4 = 0, bestSub4 = 0;
  for (let i = puzzleNums.length - 1; i >= 0; i--) {
    const r = p.puzzleScores[puzzleNums[i]];
    if (r && r.score < 7) current++; else break;
  }
  let run = 0;
  for (const pn of puzzleNums) {
    const r = p.puzzleScores[pn];
    if (r && r.score < 7) { run++; best = Math.max(best, run); } else run = 0;
  }
  for (let i = puzzleNums.length - 1; i >= 0; i--) {
    const r = p.puzzleScores[puzzleNums[i]];
    if (r && r.score <= 4) currentSub4++; else break;
  }
  let runS = 0;
  for (const pn of puzzleNums) {
    const r = p.puzzleScores[pn];
    if (r && r.score <= 4) { runS++; bestSub4 = Math.max(bestSub4, runS); } else runS = 0;
  }
  return { current, best, currentSub4, bestSub4 };
}

function getDailyWinners(puzzles, puzzleNums) {
  return puzzleNums.map(pn => {
    const p = puzzles[pn];
    const best = Math.min(...p.results.map(r => r.score));
    const winners = p.results.filter(r => r.score === best);
    return {
      num: pn,
      winners: winners.map(w => w.sender),
      score: best === 7 ? 'X' : best,
      tied: winners.length > 1,
      date: p.results[0]?.date || null,
    };
  }).reverse();
}

function getH2H(players, puzzles, puzzleNums) {
  const pairs = [];
  for (let i = 0; i < players.length; i++) {
    for (let j = i + 1; j < players.length; j++) {
      const a = players[i], b = players[j];
      let aWins = 0, bWins = 0, draws = 0;
      for (const pn of puzzleNums) {
        const ra = a.puzzleScores[pn], rb = b.puzzleScores[pn];
        if (!ra || !rb) continue;
        if (ra.score < rb.score) aWins++;
        else if (rb.score < ra.score) bWins++;
        else draws++;
      }
      if (aWins + bWins + draws > 0) pairs.push({ a: a.name, b: b.name, aWins, bWins, draws, total: aWins + bWins + draws });
    }
  }
  return pairs;
}

function getBadges(player, stats) {
  const d = getDistribution(player);
  const s = getStreaks(player, stats.puzzleNums);
  const dw = getDailyWinners(stats.puzzles, stats.puzzleNums);
  const soloWins = dw.filter(x => !x.tied && x.winners.includes(player.name)).length;
  const rank = stats.players.findIndex(p => p.name === player.name) + 1;
  const avg = avgOf(player);
  const plays = player.scores.length;
  const partPct = Math.round(plays / Math.max(1, stats.puzzleNums.length) * 100);

  const badges = [];
  if (rank === 1) badges.push({ id: 'champ', label: 'Champion', desc: 'Best average score', tier: 'gold' });
  else if (rank === 2) badges.push({ id: 'silver', label: 'Runner-up', desc: '2nd best average', tier: 'silver' });
  else if (rank === 3) badges.push({ id: 'bronze', label: 'Podium', desc: 'Top 3 average', tier: 'bronze' });
  if (d[1] >= 1) badges.push({ id: 'ace', label: 'Hole-in-one', desc: `${d[1]} × one-guess solve`, tier: 'gold' });
  if (d[2] >= 5) badges.push({ id: 'sniper', label: 'Sniper', desc: `${d[2]} two-guess solves`, tier: 'gold' });
  else if (d[2] >= 2) badges.push({ id: 'sharp', label: 'Sharpshooter', desc: `${d[2]} two-guess solves`, tier: 'silver' });
  if (s.best >= 20) badges.push({ id: 'ironman', label: 'Iron Streak', desc: `${s.best} in a row without failing`, tier: 'gold' });
  else if (s.best >= 10) badges.push({ id: 'hot', label: 'On Fire', desc: `${s.best} in a row without failing`, tier: 'silver' });
  if (s.current >= 7) badges.push({ id: 'current', label: 'Active Streak', desc: `${s.current} and counting`, tier: 'silver' });
  if (partPct >= 95) badges.push({ id: 'ever', label: 'Ever-present', desc: `${partPct}% turnout`, tier: 'gold' });
  else if (partPct >= 80) badges.push({ id: 'regular', label: 'Regular', desc: `${partPct}% turnout`, tier: 'silver' });
  if (d.X === 0 && plays >= 10) badges.push({ id: 'nofail', label: 'Never Fails', desc: 'No X across all plays', tier: 'gold' });
  if (soloWins >= 5) badges.push({ id: 'ruler', label: 'Ruler', desc: `${soloWins} solo daily wins`, tier: 'gold' });
  else if (soloWins >= 2) badges.push({ id: 'winner', label: 'Day-winner', desc: `${soloWins} solo daily wins`, tier: 'silver' });
  if (avg <= 3.5 && plays >= 10) badges.push({ id: 'elite', label: 'Sub-3.5', desc: `${avg.toFixed(2)} average`, tier: 'gold' });
  return badges;
}

window.WWStats = {
  parseChat, computeStats, getAvg, avgOf, getDistribution,
  getStreaks, getDailyWinners, getH2H, getBadges, cleanName,
};
