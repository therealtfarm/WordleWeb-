// WordleWeb — Group Stats app UI
(function () {
  const { parseChat, computeStats, getAvg, avgOf, getDistribution,
    getStreaks, getDailyWinners, getH2H, getBadges } = window.WWStats;

  let currentStats = null;
  let currentWindow = 'all';
  let currentResults = null; // raw results

  // ── Elements ─────────────────
  const $ = (id) => document.getElementById(id);
  const drop = $('drop');
  const fileIn = $('file-in');

  $('browse').addEventListener('click', e => { e.stopPropagation(); fileIn.click(); });
  drop.addEventListener('click', () => fileIn.click());
  drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('dragover'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('dragover'));
  drop.addEventListener('drop', e => {
    e.preventDefault(); drop.classList.remove('dragover');
    if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
  });
  fileIn.addEventListener('change', () => { if (fileIn.files[0]) handleFile(fileIn.files[0]); });
  $('paste').addEventListener('click', e => { e.stopPropagation(); openModal('paste-modal'); setTimeout(() => $('paste-text').focus(), 50); });
  $('paste-go').addEventListener('click', () => {
    const t = $('paste-text').value;
    if (!t.trim()) return;
    closeModal('paste-modal'); processText(t);
  });

  document.addEventListener('click', e => {
    const closeAttr = e.target.getAttribute?.('data-close');
    if (closeAttr) closeModal(closeAttr);
    if (e.target.classList?.contains('modal')) closeModal(e.target.id);
  });
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') document.querySelectorAll('.modal.open').forEach(m => m.classList.remove('open'));
  });

  function openModal(id) { $(id).classList.add('open'); }
  function closeModal(id) { $(id).classList.remove('open'); }

  function showError(msg) { const e = $('err'); e.textContent = msg; e.classList.remove('hidden'); }
  function clearError() { $('err').classList.add('hidden'); }

  // ── File handling ──────────
  function handleFile(file) {
    clearError();
    const reader = new FileReader();
    reader.onload = async (e) => {
      const buffer = e.target.result;
      const bytes = new Uint8Array(buffer);
      const isZip = bytes.length > 4 && bytes[0] === 0x50 && bytes[1] === 0x4B;
      if (isZip && typeof JSZip !== 'undefined') {
        try {
          const zip = await JSZip.loadAsync(buffer);
          const txtFile = Object.values(zip.files).find(f => f.name.endsWith('.txt') && !f.dir);
          if (!txtFile) return showError('No .txt file inside the ZIP.');
          const text = await txtFile.async('string');
          processText(text);
        } catch (err) { showError('Could not read ZIP: ' + err.message); }
      } else {
        processText(new TextDecoder('utf-8').decode(buffer));
      }
    };
    reader.onerror = () => showError('Could not read file.');
    reader.readAsArrayBuffer(file);
  }

  function processText(text) {
    const results = parseChat(text);
    if (!results.length) return showError('No Wordle results found in that chat.');
    currentResults = results;
    // Save to localStorage
    try {
      localStorage.setItem('ww_stats_cache', JSON.stringify(results));
      localStorage.setItem('ww_stats_date', new Date().toISOString());
    } catch (e) { /* storage full or disabled */ }
    render();
    // Hide upload
    $('upload-view').classList.add('hidden');
    $('results-view').classList.remove('hidden');
  }

  // Load cached stats on page load
  function loadCached() {
    try {
      const cached = localStorage.getItem('ww_stats_cache');
      const cacheDate = localStorage.getItem('ww_stats_date');
      if (cached) {
        currentResults = JSON.parse(cached);
        // Convert date strings back to Date objects
        currentResults.forEach(r => { r.date = new Date(r.date); });
        render();
        $('upload-view').classList.add('hidden');
        $('results-view').classList.remove('hidden');
        // Show cache age indicator
        if (cacheDate) {
          const age = new Date() - new Date(cacheDate);
          const days = Math.floor(age / (1000*60*60*24));
          const hint = days === 0 ? 'today' : days === 1 ? 'yesterday' : days + 'd ago';
          const badge = document.createElement('div');
          badge.style.cssText = 'position:fixed; top:60px; right:12px; font-family: var(--font-mono); font-size: 10px; color: var(--ink-mute); background: var(--paper-2); padding: 6px 10px; border-radius: 6px; border: 1px solid var(--rule); z-index: 10;';
          badge.textContent = '📊 Cached ' + hint;
          document.body.appendChild(badge);
        }
      }
    } catch (e) { /* corrupted cache, ignore */ }
  }
  loadCached();

  // ── Rendering ──────────────
  function fmtDate(d) {
    if (!d) return '';
    const m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return `${d.getDate()} ${m[d.getMonth()]} ${d.getFullYear()}`;
  }
  function fmtDateShort(d) {
    if (!d) return '';
    const m = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return `${d.getDate()} ${m[d.getMonth()]}`;
  }
  function getCacheAge() {
    try {
      const cacheDate = localStorage.getItem('ww_stats_date');
      if (!cacheDate) return null;
      const date = new Date(cacheDate);
      const age = new Date() - date;
      const days = Math.floor(age / (1000*60*60*24));
      const hours = Math.floor((age % (1000*60*60*24)) / (1000*60*60));
      if (days > 0) return `${days}d ${hours}h ago`;
      if (hours > 0) return `${hours}h ago`;
      return 'just now';
    } catch (e) { return null; }
  }

  function render() {
    const stats = computeStats(currentResults, currentWindow);
    currentStats = stats;
    const el = $('results-view');

    const range = stats.dateRange;
    const cacheAge = getCacheAge();
    let html = '';

    // Filter bar + reset
    html += `
      <div class="filter-bar">
        <div class="ww-seg" id="win-seg">
          <button data-win="all" aria-pressed="${currentWindow==='all'}">All</button>
          <button data-win="90" aria-pressed="${currentWindow==='90'}">90d</button>
          <button data-win="30" aria-pressed="${currentWindow==='30'}">30d</button>
          <button data-win="7" aria-pressed="${currentWindow==='7'}">7d</button>
        </div>
        <div style="display:flex; gap: 8px; align-items:center;">
          <button class="btn" id="share-btn" title="Share card">⇪ Share</button>
          <button class="btn" id="reload-btn" title="Load different chat">↻</button>
        </div>
      </div>
    `;

    if (!stats.players.length || !stats.puzzleNums.length) {
      html += `<div class="section"><div style="text-align:center; padding:40px; color: var(--ink-mute);">No results in this window.</div></div>`;
      el.innerHTML = html;
      attachTopHandlers();
      return;
    }

    // Overview strip
    html += `
      <div class="section">
        <div style="display:flex; gap:6px; flex-wrap:wrap;">
          <span class="ww-pill"><strong>${stats.puzzleNums.length}</strong> puzzles</span>
          <span class="ww-pill"><strong>${stats.players.length}</strong> players</span>
          <span class="ww-pill"><strong>${stats.totalResults}</strong> results</span>
          ${range ? `<span class="ww-pill">${fmtDateShort(range.from)} → ${fmtDateShort(range.to)}</span>` : ''}
          <span class="ww-pill">X / 6 = <strong>7</strong></span>
        </div>
        ${cacheAge ? `<div style="margin-top: 10px; font-family: var(--font-mono); font-size: 10px; color: var(--ink-mute); letter-spacing: 0.04em;">📊 Imported ${cacheAge}</div>` : ''}
      </div>
    `;

    // Leaderboard
    html += `<div class="section">
      <div class="section-head">
        <div class="section-title">Leaderboard</div>
        <div class="section-sub">By average</div>
      </div>
      <div class="lb">`;
    stats.players.forEach((p, idx) => {
      const d = getDistribution(p);
      const max = Math.max(...Object.values(d), 1);
      const keys = [1,2,3,4,5,6,'X'];
      const barsHtml = keys.map(k => {
        const v = d[k] || 0;
        const h = Math.round((v/max) * 26);
        const cls = k === 'X' ? 'bx' : `b${k}`;
        return `<div class="lb-bar ${cls}" style="height:${Math.max(2,h)}px" title="${k}: ${v}"></div>`;
      }).join('');
      html += `
        <div class="lb-row r${idx+1}" data-player="${esc(p.name)}">
          <div class="lb-rank">${String(idx+1).padStart(2,'0')}</div>
          <div>
            <div class="lb-name">${esc(p.name)}</div>
            <div class="lb-plays">${p.scores.length} plays</div>
          </div>
          <div class="lb-bars">${barsHtml}</div>
          <div>
            <div class="lb-avg">${getAvg(p)}</div>
            <div class="lb-avg-sub">Avg</div>
          </div>
        </div>
      `;
    });
    html += `</div></div>`;

    // Recent form
    const formN = Math.min(15, stats.puzzleNums.length);
    const recent = stats.puzzleNums.slice(-formN);
    html += `<div class="section">
      <div class="section-head">
        <div class="section-title">Recent form</div>
        <div class="section-sub">Last ${formN} puzzles</div>
      </div>
      <div class="form-strip"><table class="form-table"><thead><tr><th></th>`;
    recent.forEach(pn => { html += `<th>${pn}</th>`; });
    html += `<th>AVG</th></tr></thead><tbody>`;
    stats.players.forEach(p => {
      html += `<tr><td class="nm">${esc(p.name)}</td>`;
      const played = [];
      recent.forEach(pn => {
        const r = p.puzzleScores[pn];
        if (!r) html += `<td><span class="fc miss">·</span></td>`;
        else if (r.score === 7) { html += `<td><span class="fc fx">X</span></td>`; played.push(7); }
        else { html += `<td><span class="fc f${r.score}">${r.score}</span></td>`; played.push(r.score); }
      });
      const avg = played.length ? (played.reduce((s,v)=>s+v,0)/played.length).toFixed(1) : '–';
      html += `<td class="avg">${avg}</td></tr>`;
    });
    html += `</tbody></table></div></div>`;

    // Records
    const dw = getDailyWinners(stats.puzzles, stats.puzzleNums);
    const mostTwos = topBy(stats.players, p => getDistribution(p)[2]);
    const mostThrees = topBy(stats.players, p => getDistribution(p)[3]);
    const fewestX = topBy(stats.players.filter(p => p.scores.length >= Math.max(10, stats.puzzleNums.length * 0.3)), p => -getDistribution(p).X);
    const soloWinner = topBy(stats.players, p => dw.filter(x => !x.tied && x.winners.includes(p.name)).length);
    const bestPart = topBy(stats.players, p => p.scores.length);
    const bestStreak = topBy(stats.players, p => getStreaks(p, stats.puzzleNums).best);

    const records = [
      { label: '2-guess solves', val: mostTwos ? getDistribution(mostTwos)[2] : 0, who: mostTwos?.name || '–' },
      { label: '3-guess solves', val: mostThrees ? getDistribution(mostThrees)[3] : 0, who: mostThrees?.name || '–' },
      { label: 'Fewest fails', val: fewestX ? getDistribution(fewestX).X : '–', who: fewestX?.name || '–' },
      { label: 'Solo wins', val: soloWinner ? dw.filter(x => !x.tied && x.winners.includes(soloWinner.name)).length : 0, who: soloWinner?.name || '–' },
      { label: 'Best streak', val: bestStreak ? getStreaks(bestStreak, stats.puzzleNums).best : 0, who: bestStreak?.name || '–' },
      { label: 'Most plays', val: bestPart ? bestPart.scores.length : 0, who: bestPart?.name || '–' },
    ];
    html += `<div class="section">
      <div class="section-head"><div class="section-title">Records</div><div class="section-sub">Notable</div></div>
      <div class="records">`;
    records.forEach(r => {
      html += `<div class="record">
        <div class="record-label">${r.label}</div>
        <div class="record-value">${r.val}</div>
        <div class="record-who">${esc(r.who)}</div>
      </div>`;
    });
    html += `</div></div>`;

    // Streaks
    html += `<div class="section">
      <div class="section-head"><div class="section-title">Streaks</div><div class="section-sub">Consecutive solves</div></div>
      <div class="streak-head"><div>Player</div><div>Now</div><div>Best</div><div>Now ≤4</div><div>Best ≤4</div></div>
      <div class="streaks">`;
    stats.players.forEach(p => {
      const s = getStreaks(p, stats.puzzleNums);
      html += `<div class="streak-row">
        <div class="sn">${esc(p.name)}</div>
        <div class="sv">${s.current || '–'}</div>
        <div class="sv hot">${s.best || '–'}</div>
        <div class="sv">${s.currentSub4 || '–'}</div>
        <div class="sv hot">${s.bestSub4 || '–'}</div>
      </div>`;
    });
    html += `</div></div>`;

    // H2H
    const h2h = getH2H(stats.players, stats.puzzles, stats.puzzleNums);
    if (h2h.length) {
      html += `<div class="section">
        <div class="section-head"><div class="section-title">Head to head</div><div class="section-sub">Pairwise</div></div>
        <div class="h2h-list">`;
      h2h.forEach(pair => {
        const aPct = pair.aWins / pair.total * 100;
        const dPct = pair.draws / pair.total * 100;
        const bPct = pair.bWins / pair.total * 100;
        html += `<div class="h2h">
          <div class="h2h-top">
            <span class="h2h-a">${esc(pair.a)}</span>
            <span class="h2h-score">${pair.aWins} · ${pair.bWins}</span>
            <span class="h2h-b">${esc(pair.b)}</span>
          </div>
          <div class="h2h-bar">
            <span class="a" style="width:${aPct}%"></span>
            <span class="d" style="width:${dPct}%"></span>
            <span class="b" style="width:${bPct}%"></span>
          </div>
          <div class="h2h-meta">${pair.total} head-to-head · ${pair.draws} draw${pair.draws===1?'':'s'}</div>
        </div>`;
      });
      html += `</div></div>`;
    }

    // Daily winners
    html += `<div class="section">
      <div class="section-head"><div class="section-title">Daily winners</div><div class="section-sub">Per puzzle</div></div>
      <div class="daily" id="daily-list">`;
    const show = Math.min(15, dw.length);
    dw.forEach((d, i) => {
      const vis = i < show ? '' : 'style="display:none" data-extra';
      html += `<div class="daily-item" ${vis}>
        <span class="daily-num">#${d.num}</span>
        <span class="daily-w">${d.winners.map(esc).join(', ')}${d.tied?'<span class="daily-tied">tied</span>':''}</span>
        <span class="daily-s">${d.score}/6</span>
      </div>`;
    });
    html += `</div>`;
    if (dw.length > show) {
      html += `<button class="more-btn" id="more-daily">Show all ${dw.length}</button>`;
    }
    html += `</div>`;

    el.innerHTML = html;
    attachTopHandlers();
    attachResultHandlers();
  }

  function attachTopHandlers() {
    document.querySelectorAll('#win-seg button').forEach(btn => {
      btn.addEventListener('click', () => {
        currentWindow = btn.dataset.win;
        render();
      });
    });
    const rb = $('reload-btn');
    if (rb) rb.addEventListener('click', () => {
      $('upload-view').classList.remove('hidden');
      $('results-view').classList.add('hidden');
      currentResults = null;
      fileIn.value = '';
    });
    const sb = $('share-btn');
    if (sb) sb.addEventListener('click', openShare);
  }

  function attachResultHandlers() {
    document.querySelectorAll('.lb-row').forEach(row => {
      row.addEventListener('click', () => openProfile(row.dataset.player));
    });
    const md = $('more-daily');
    if (md) md.addEventListener('click', () => {
      document.querySelectorAll('[data-extra]').forEach(e => e.style.display = '');
      md.remove();
    });
  }

  function topBy(list, fn) {
    let best = null, bv = -Infinity;
    for (const p of list) {
      const v = fn(p);
      if (v > bv) { bv = v; best = p; }
    }
    return best;
  }

  function esc(s) { return String(s).replace(/[<>&"]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c])); }

  // ── Profile ──────────────
  function openProfile(name) {
    const p = currentStats.players.find(x => x.name === name);
    if (!p) return;
    const d = getDistribution(p);
    const s = getStreaks(p, currentStats.puzzleNums);
    const max = Math.max(...Object.values(d), 1);
    const rank = currentStats.players.findIndex(x => x.name === name) + 1;
    const dw = getDailyWinners(currentStats.puzzles, currentStats.puzzleNums);
    const soloWins = dw.filter(x => !x.tied && x.winners.includes(name)).length;
    const badges = getBadges(p, currentStats);

    $('prof-title').textContent = p.name;
    $('prof-body').innerHTML = `
      <div class="prof-avg-row">
        <div class="prof-stat"><div class="v">${getAvg(p)}</div><div class="l">Average</div></div>
        <div class="prof-stat"><div class="v">#${rank}</div><div class="l">Rank</div></div>
        <div class="prof-stat"><div class="v">${s.best}</div><div class="l">Streak</div></div>
        <div class="prof-stat"><div class="v">${soloWins}</div><div class="l">Solo wins</div></div>
      </div>

      <div class="sub-label">Distribution</div>
      <div class="prof-dist">
        ${[1,2,3,4,5,6,'X'].map(k => {
          const v = d[k] || 0;
          const pct = (v/max)*100;
          const cls = k === 'X' ? 'd-x' : `d-${k}`;
          return `<div class="prof-d-row">
            <div class="prof-d-lbl">${k}</div>
            <div class="prof-d-bar-wrap"><div class="prof-d-bar" style="width:${pct}%; background: var(--${cls});"></div></div>
            <div class="prof-d-count">${v}</div>
          </div>`;
        }).join('')}
      </div>

      <div class="sub-label">Badges (${badges.length})</div>
      <div class="badges">
        ${badges.length ? badges.map(b => `<div class="badge ${b.tier}">
          <span class="badge-dot"></span>
          <span class="badge-name">${esc(b.label)}</span>
          <span class="badge-desc">· ${esc(b.desc)}</span>
        </div>`).join('') : '<div style="color:var(--ink-mute); font-size: 12px;">No badges yet — keep playing.</div>'}
      </div>

      <div class="sub-label">Last 20</div>
      <div style="display:flex; flex-wrap:wrap; gap:3px;">
        ${currentStats.puzzleNums.slice(-20).map(pn => {
          const r = p.puzzleScores[pn];
          if (!r) return `<span class="fc miss" title="#${pn}: missed">·</span>`;
          if (r.score === 7) return `<span class="fc fx" title="#${pn}: X">X</span>`;
          return `<span class="fc f${r.score}" title="#${pn}: ${r.score}/6">${r.score}</span>`;
        }).join('')}
      </div>
    `;
    openModal('profile-modal');
  }

  // ── Share card ────────────
  function openShare() {
    const stats = currentStats;
    const top = stats.players.slice(0, Math.min(6, stats.players.length));
    const dw = getDailyWinners(stats.puzzles, stats.puzzleNums);
    const leaderStr = top.map((p,i) => {
      return `<div style="display:grid; grid-template-columns: 18px 1fr auto; gap:10px; align-items:baseline; padding:6px 0; border-bottom: 1px dashed var(--rule);">
        <span style="font-family: var(--font-mono); font-size: 11px; color: var(--ink-faint);">${String(i+1).padStart(2,'0')}</span>
        <span style="font-family: var(--font-display); font-weight: 700; font-size: 18px; letter-spacing: -0.01em;">${esc(p.name)}</span>
        <span style="font-family: var(--font-mono); font-weight: 700; font-size: 15px;">${getAvg(p)}</span>
      </div>`;
    }).join('');

    const range = stats.dateRange;
    $('share-card').innerHTML = `
      <div style="display:flex; align-items:baseline; justify-content: space-between; margin-bottom: 14px;">
        <span style="font-family: var(--font-display); font-weight: 800; font-size: 18px; letter-spacing: -0.01em;">WordleWeb</span>
        <span style="font-family: var(--font-mono); font-size: 9px; color: var(--ink-mute); letter-spacing: 0.14em; text-transform: uppercase;">Group Stats</span>
      </div>
      <div style="font-family: var(--font-display); font-weight: 800; font-size: 28px; line-height: 1.02; letter-spacing: -0.025em; margin-bottom: 4px;">The standings.</div>
      <div style="font-family: var(--font-mono); font-size: 10.5px; color: var(--ink-mute); letter-spacing: 0.04em; margin-bottom: 16px;">${range ? fmtDateShort(range.from) + ' → ' + fmtDateShort(range.to) : ''} · ${stats.puzzleNums.length} puzzles</div>
      ${leaderStr}
      <div style="flex:1"></div>
      <div style="margin-top: 14px; padding-top: 14px; border-top: 1px solid var(--rule); display:flex; justify-content: space-between; font-family: var(--font-mono); font-size: 9px; color: var(--ink-faint); letter-spacing: 0.1em; text-transform: uppercase;">
        <span>${stats.totalResults} results · ${stats.players.length} players</span>
        <span>wordleweb</span>
      </div>
    `;
    openModal('share-modal');
  }

  $('share-download').addEventListener('click', async () => {
    const card = $('share-card');
    const scale = 3;
    // Use html-to-image via inline rendering — fallback to simple approach
    try {
      const svg = await htmlToSvg(card);
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = card.offsetWidth * scale;
        canvas.height = card.offsetHeight * scale;
        const ctx = canvas.getContext('2d');
        ctx.scale(scale, scale);
        ctx.drawImage(img, 0, 0);
        canvas.toBlob(blob => {
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = 'wordleweb-stats.png';
          a.click();
        });
      };
      img.src = svg;
    } catch (e) {
      alert('Could not export image.');
    }
  });

  async function htmlToSvg(el) {
    // Clone and inline styles briefly
    const rect = el.getBoundingClientRect();
    const styles = getComputedStyle(el);
    const bg = styles.background || styles.backgroundColor;
    const clone = el.cloneNode(true);
    // Flatten computed styles on the clone to avoid CSS-var dependency
    inlineAll(el, clone);
    const xhtml = new XMLSerializer().serializeToString(clone);
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${rect.width}" height="${rect.height}">
      <foreignObject width="100%" height="100%">
        <div xmlns="http://www.w3.org/1999/xhtml" style="width:${rect.width}px;height:${rect.height}px;">${xhtml}</div>
      </foreignObject>
    </svg>`;
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }
  function inlineAll(src, dst) {
    const s = getComputedStyle(src);
    // Copy critical text + layout props
    const keys = ['font','fontFamily','fontWeight','fontSize','fontStyle','color','background','backgroundColor','border','borderRadius','padding','margin','display','alignItems','justifyContent','gap','width','height','letterSpacing','lineHeight','textTransform','textAlign','gridTemplateColumns','flexDirection','flex','opacity'];
    keys.forEach(k => { try { dst.style[k] = s[k]; } catch {} });
    const sKids = src.children, dKids = dst.children;
    for (let i = 0; i < sKids.length; i++) inlineAll(sKids[i], dKids[i]);
  }

})();
